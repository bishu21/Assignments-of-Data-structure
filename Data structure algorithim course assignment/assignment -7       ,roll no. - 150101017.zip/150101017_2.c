/*
	name - Bishwendra choudhary
	roll no. - 150101017
*/	

#include <stdio.h>
#include <stdlib.h>
 
/* a structure to represent an edge in graph
		there x and y are used as to define two node which are connected
	*/	
struct Edge
{
    int x, y;
};
 
/*  a structure to represent a graph
		
*/
struct Graph
{
    // V-> Number of vertices, E-> Number of edges
    int V, E;
 
    // graph is represented as an array of edges
    struct Edge* edge;
};
 
struct subset
{
    int parent;
    int rank;
};
 
// Creates a graph with V vertices and E edges
struct Graph* createGraph(int V, int E)
{
    struct Graph* graph = (struct Graph*) malloc( sizeof(struct Graph) );
    graph->V = V;
    graph->E = E;
 
    graph->edge = (struct Edge*) malloc( graph->E * sizeof( struct Edge ) );
 
    return graph;
}
 
// A utility function to find set of an element i
// (uses path compression technique)
int find(struct subset subsets[], int i)
{
    // find root and make root as parent of i (path compression)
    if (subsets[i].parent != i)
        subsets[i].parent = find(subsets, subsets[i].parent);
 
    return subsets[i].parent;
}
 
// A function that does union of two sets of x and y
// (uses union by rank)
void Union(struct subset subsets[], int x, int y)
{
    int xroot = find(subsets, x);
    int yroot = find(subsets, y);
 
    /* Attach smaller rank tree under root of high rank tree
    		there we use path compression so don't increse rank value of representative when they have different rank 
    		because  connect every node directly to representative
	 (Union by Rank)
	 */
    if (subsets[xroot].rank < subsets[yroot].rank)
        subsets[xroot].parent = yroot;
    else if (subsets[xroot].rank > subsets[yroot].rank)
        subsets[yroot].parent = xroot;
 
    /*If ranks are same, then make one as root and increment
     its rank by one
    
	*/
	else
    {
        subsets[yroot].parent = xroot;
        subsets[xroot].rank++;
    }
}
/*
	by this we print the output and before we call union function and find set also
	*/
void pathcompression( struct Graph* graph )
{
    int V = graph->V;
    int E = graph->E;
 
    /* Allocate memory for creating V sets
    	make V size of array linklist 
    	*/
	struct subset *subsets =
        (struct subset*) malloc( V * sizeof(struct subset) );
 	int v;
    for ( v = 0; v < V; ++v)
    {
        subsets[v].parent = v;
        subsets[v].rank = 0;
    }
 
   
    int e;
    for(e = 0; e < E; ++e)
    {
        int x = find(subsets, graph->edge[e].x);
        int y = find(subsets, graph->edge[e].y);
 
     	/*
     		if x==y then they are already belong from same set 
     		*/
 		if(x!=y)
        Union(subsets, x, y);
    }
    
    printf("Enter value '1' for find representative");
    printf("\n\nEnter value '2' for Disjoint set");
    printf("\n\nEnter '3' for exit\n");
    
    int l,r;
    scanf("%d",&l);
    /*
    	switch fx used to get result in proper way
    	*/
    switch (l)
    {
    	case 1 : 
    		{
    			printf("type a node whose representative you want to find :");
    			scanf("%d",&r);
    			printf("%d",find(subsets,r));
    			break;
			}
			
		case 2 :
			{
				printf("\nDisjoint sets are :\n");
				
				int k=0;
   				for(e=0;e<V;e++)
   				{
   		
   				int l=find(subsets,e);
   				if(k==l)
   					printf("%d",e);
   				/*
				   if they have different representative node so they disjoint 
				   so give next line for that
				   */	
   				else
   				{
					printf("\n");
					/*
						assign that different representative
						*/
					k=l;
					printf("%d",e);
	   			}
	   			
	   			}
	   			break;
			}
		case 3:
		{
		      /* for exit the switch
			  */	 
			   
			break;
		}
			
		
	}
    
}

 
// Driver program to test above functions
int main()
{
   
   /*
   	you can change value of V and E and value of graph->edge 
   	arrey linklist and get  correct result 
   	*/
 
    int V = 5, E = 3,i;
    struct Graph* graph = createGraph(V, E);
 	
 		/*
 	for taking example put below case 
 	*/
 	printf("put the edges whose you want to connect :\n");
 	
 	for(i=0;i<E;i++)
 	{
 		scanf("%d",&graph->edge[i].x);
 		scanf("%d",&graph->edge[i].y);
	 }
  /*  // add edge 0-1
    graph->edge[0].x = 0;
    graph->edge[0].y = 1;
 
    // add edge 1-2
    graph->edge[1].x = 2;
    graph->edge[1].y = 3;
 
    // add edge 0-2
  	graph->edge[2].x = 3;
    graph->edge[2].y = 4;
 */
    pathcompression(graph);
 
      
 
    return 0;
}
