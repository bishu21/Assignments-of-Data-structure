/*
	name - Bishwendra choudhary
	roll no. - 150101017
*/	

#include<stdio.h>
#include<stdlib.h>

/*to heapify a subtree with root at given index
	and get minimum elements from a array
	*/
void MinHeapify(int arr[], int i, int n)
{
	int temp;
    int l = 2*i + 1;
    int r = 2*i + 2;
    int smallest = i;
    if (l < n && arr[l] < arr[i])
        smallest = l;
    if (r < n && arr[r] < arr[smallest])
        smallest = r;
    if (smallest != i)
    {
    	temp=arr[i];
    	arr[i]=arr[smallest];
    	arr[smallest]=temp;
        
        MinHeapify(arr, smallest, n);
    }
    
}
 /*
 	this function is just required function of
 	heap sort
 	*/

void Extractmin(int A[],int n)
{
	int i;
	for (i = (n-2)/2; i >= 0; --i)
        MinHeapify(A, i, n);
        
        
       
        
}

void main()
{
	int j=0,i=0,a,b,c,d,k,A[1000],B[1000];
	printf("No. of insert elements :");
	scanf("%d",&a);
	printf("No. of extract Min. function :");
	scanf("%d",&b);
	/*
		assign all element of array as big no.
		which is greater than your inputs
		*/
	for(k=0;k<a;k++)
	{
		A[k]=1000;
	}
	/*
	 this is required loop to takes input from user that how many no.s you want to add
	 */
	for(k=0;k<(a+b);k++)
	{
	
	printf("press '1' for insert elements :\n\n");
	printf("press '2' for apply Extract Min. fxn :\n");
	
	scanf("%d",&c);
	
	switch(c)
	{
		case 1 :
		{
				
				printf("Enter the no.");
				scanf("%d",&d);
				A[i]=d;
				i++;
				break;
		}	
		case 2 :
		{
				Extractmin(A,i);
				/*
					there I stored the minimum value of given set 
					*/	
				B[j]=A[0];
				A[0]=1000;
				j++;
				
		}	
	}
	}
	printf("Given extract set is :");
	for(k=0;k<j;k++)
	{
		printf("%d ",B[k]);
	}
}
