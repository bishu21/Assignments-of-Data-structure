/*bishwendra choudhary
  roll no. =150101017 */

#include<stdio.h>
#include<stdlib.h>
#include<time.h>
struct node
{
	struct node *left;
	struct node *right;
	struct node *father;
	int info ;
}*temp,*start,*current,*head,*first,*qwe;
struct node* find(struct node* root, int key)//find funtion cheack for repeatation
{
    //there is two case that is - root is null or key is present at root
    if (root == NULL || root->info ==key)
       return root;
    
    // Key is greater than root's key
    if (root->info < key)
       return find(root->right, key);
 
    //else used this for smaller
    return find(root->left, key);
}
/* it is a ceate node funtion */
struct node *createnode(int b)
{
	temp=(struct node *)malloc(sizeof(struct node));
	temp->info=b;
	temp->left=NULL;
	temp->right=NULL;
	temp->father=NULL;
	
	return temp;
}

void maketree(int a[])
{
	int i,q;
	for(i=0;i<100;i++)
	{	
		qwe=find(first,a[i]);	//if no. is repeat in binary search tree then delete that no.
		if(qwe==NULL)
		{
		 head = createnode(a[i]); // head is my new create node
		 
		if(i>=1)			//after making first node we use this 
		{
			
			current=first;   //intially my current,start,first all pointers are at first node 
			start=first;	
			while(1)
			{
			current=start;
			
			if(a[i]>current->info)		
			{
				start=start->right;
				if(start==NULL)						//it is the condition of leaf node  
				{
					current->right=head;	// there i used current node as parent of start node
					break;
				}
			}
			
			else if(a[i]<current->info)									//same thing done there also
			{
				start=start->left;
				if(start==NULL)
				{
					current->left=head;	
					break ;
				}	
			}
			
			}
				
		}
		
		else       					//*it is the condition of first node making 
		{
			current=head;   
			start=head;	
			first=head;
			
		}
		}
	}
}
struct node * search (struct node *first ,int n1,int n2)
// There n1 and n2 are that nodes whose LCA we are going to find
{
	if(first==NULL)
	return NULL;
	
	/*  very easy condition to find LCA that when  first->info is greater that one node and less that other then given 
	node is LCA of both numbers   */
	
	if(first->info <n1&&first->info<n2)	
	return search(first->right,n1,n2);
	
	if(first->info >n1&&first->info>n2)
	return search(first->left,n1,n2);
	
	
	return first;
}

// A function that terminates when enter key is pressed
void fun()
{
    printf("fun() starts \n");
    printf("Press enter to stop fun \n");
    while(1)
    {
        if (getchar())
            break;
    }
    printf("fun() ends \n");
}
void main ()
{
	int i,a[500],l,k;
	time_t y;					
	//time is variable so we use seed as time
	 /* Intializes random number generator */
   srand((unsigned) time(&y));
   
   
	for(i=0;i<100;i++)
	{
		
		a[i]=rand()%(100);		//take a random funtion
		printf("%d ",a[i]);			
	}	
	maketree(a);
	
	printf("\n\n\nPUT node value whose LCA you want find : ");
	scanf("%d",&l);
	
	scanf("%d",&k);
	getchar();
	if(l==k)						
		//condition for that no.s put should be differnet
	
	printf("\nERROR two node value never same in binary search tree ");
	else 
	{
		//there I call the funtion search to get LCA
	temp=search(first ,l,k);	
	printf("\nLCA of above nodes is :%d\n",temp->info);			//print the LCA
	}
	
		// Calculate the time taken by fun()
    clock_t t;
    t = clock();
    fun();
    t = clock() - t;
    double time_taken = ((double)t)/CLOCKS_PER_SEC; // in seconds
 
    printf("fun() took %f seconds to execute \n", time_taken);
}

/* 
		"these all are average time complexity "
	there 'n' is number of total nodes
	 
  time complexity of 'make tree'  funtion  is O(logn) 
  time complexity of 'find' funtion is O(logn)
  time complexity of 'search' function is  O(logn)
  time complexity of void funtion is O(1) beacause I access once for loop 
  
  total complexity is sum of these complexity 
*/
  
  
