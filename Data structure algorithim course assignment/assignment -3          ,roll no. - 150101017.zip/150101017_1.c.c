/*bishwendra choudhary
  roll no. =150101017 */


#include<stdio.h>
#include<stdlib.h>

/* structure is defined*/
struct node 
{
	struct node *left;
	struct node *right;
	struct node *father;
	int info ;
}*temp,*start,*current,*head,*first,*qwe;
/* it is a ceate node funtion */
struct node *createnode(int b)
{
	temp=(struct node *)malloc(sizeof(struct node));
	temp->info=b;
	temp->left=NULL;
	temp->right=NULL;
	temp->father=NULL;
	
	return temp;
}


struct node* search(struct node* root, int key)
{
    //there is two case that is - root is null or key is present at root
    if (root == NULL || root->info ==key)
       return root;
    
    // Key is greater than root's key
    if (root->info < key)
       return search(root->right, key);
 
    //else used this for smaller
    return search(root->left, key);
}
/* from this funtion we make a binary tree */
void maketree(int a[])
{
	int i,q;
	for(i=0;i<100;i++)
	{	
		qwe=search (first,a[i]);	//if no. is repeat in binary search tree then delete that no.
		if(qwe==NULL)
		{
		head = createnode(a[i]); // head is my create node
		 
		if(i>=1)			//after making first node we use this 
		{
			
			current=first;   //intially my current,start,first all pointers are at first node 
			start=first;	
			while(1)
			{
			current=start;
			
			if(a[i]>current->info)		
			{
				start=start->right;
				if(start==NULL)						//it is the condition of leaf node  
				{
					current->right=head;			// there i used current node as parent of start node
					break;
				}
			}
			
			else if(a[i]<current->info)										//same thing done there also
			{
				start=start->left;
				if(start==NULL)
				{
					current->left=head;	
					break ;
				}	
			}
			
			}
				
		}
		
		else       					//*it is the condition of first node making 
		{
			current=head;   
			start=head;	
			first=head;
			
		}	
	}}
}


int maxDepth(struct node* first) 
{
   if (first==NULL) 
       return 0;
   else
   {
       /* compute the depth of each subtree */
       int lDepth = maxDepth(first->left);
       int rDepth = maxDepth(first->right);
 
       /* use the larger one */
       if (lDepth > rDepth) 
           return(lDepth+1);
       else return(rDepth+1);
   }
} 
int mindepth(struct node* first) 
{
   if (first==NULL) 
       return 0;
   else
   {
       /* compute the depth of each subtree */
       int lDepth = maxDepth(first->left);
       int rDepth = maxDepth(first->right);
 
       /* use the smaller one */
       if (lDepth > rDepth) 
           return(rDepth+1);
       else return(rDepth+1);
   }
} 
void main ()
{
	int i,a[500],l,r,j,b[500],count=0;
	
	time_t t;	   //define a seed used in random funtion
	
	 /* Intializes random number generator */
  	srand((unsigned) time(&t));	
   
	for(j=0;j<50;j++)
	{
		
	for(i=0;i<100;i++)
	{
		
		a[i]=rand()%(100);		//take a rand() 
		printf("%d ",a[i]);		
	}	
	maketree(a);				// call the make tree funtion to make tree and pass the random no.s
	
	l=	maxDepth(first);						//it is for find max. depth
	printf("\nmaximum height is %d",l);
	r=mindepth(first);
	printf("\nminimum height is %d",r);			//it is for find min. depth
	printf("\ndifference :%d\n",l-r);
	b[j]=l-r;									//put difference into arrey that is b[]
	}

	for(i=0;i<99;i++)                      //it is for counting the frequency of every difference
	{
		count=0;
		for(j=0;j<50;j++)
		{
			if(i==b[j])
			{
			count++;
			b[j]==-1;
			}	
		}
		if(count==0)
		continue;
		printf("difference of '%d'comes  %d times\n",i,count);
	}
	
}
