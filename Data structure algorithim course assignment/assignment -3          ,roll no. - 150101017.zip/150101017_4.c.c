/*bishwendra choudhary
  roll no. =150101017 */
  
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
struct node
{
	struct node *left;
	struct node *right;
	struct node *father;
	int info ;
}*temp,*start,*current,*head,*first,*qwe;
struct node* find(struct node* root, int key)		//find funtion cheack for repeatation
{
    //there is two case that is - root is null or key is present at root
    if (root == NULL || root->info ==key)
       return root;
    
    // Key is greater than root's key
    if (root->info < key)
       return find(root->right, key);
 
    //else used this for smaller
    return find(root->left, key);
}
/* 
	it is a ceate node funtion used to make a new node
*/
struct node *createnode(int b)
{
	temp=(struct node *)malloc(sizeof(struct node));
	temp->info=b;
	temp->left=NULL;
	temp->right=NULL;
	temp->father=NULL;
	
	return temp;
}

void maketree(int a[])
{
	int i,q;
	for(i=0;i<100;i++)
	{	
		qwe=find(first,a[i]);	//if no. is repeat in binary search tree then delete that no.
		if(qwe==NULL)
		{
		 head = createnode(a[i]); // head is my new create node
		 
		if(i>=1)			//after making first node we use this 
		{
			
			current=first;   //intially my current,start,first all pointers are at first node 
			start=first;	
			while(1)
			{
			current=start;
			
			if(a[i]>current->info)		
			{
				start=start->right;
				if(start==NULL)						//it is the condition of leaf node  
				{
					current->right=head;			// there i used current node as parent of start node
					break;
				}
			}
			
			else if(a[i]<current->info)									//same thing done there also
			{
				start=start->left;
				if(start==NULL)
				{
					current->left=head;	
					break ;
				}	
			}
			
			}
				
		}
		
		else       					//*it is the condition of first node making 
		{
			current=head;   
			start=head;	
			first=head;
			
		}
		}
	}
}
int depth(struct node* first,int n1) 
{
   if (first==NULL) 
       return 0;
    temp =find(first,n1);
   if(temp!=NULL)
   {
       /* compute the depth of each subtree */
       int lDepth = depth(first->left,n1);
       int rDepth = depth(first->right,n1);
 
       /* use the smaller one */
       if (lDepth > rDepth) 
           return(lDepth+1);
       else return(rDepth+1);
   }
  
} 
struct node * search (struct node *first ,int n1,int n2)
// There n1 and n2 are that nodes whose LCA we are going to find
{
	if(first==NULL)
	return NULL;
	
	/*  very easy condition to find LCA that when  first->info is greater that one node while less that other then given 
	node is LCA of both numbers   */
	
	if(first->info <n1&&first->info<n2)	
	return search(first->right,n1,n2);
	
	if(first->info >n1&&first->info>n2)
	return search(first->left,n1,n2);
	
	
	return first;
} 
int *findleaf(struct node *first)//  it is pointer findleaf funtion used to return arrey  
{
	static int count=0,b[100];
	
	if(first!=NULL)					
	{
		findleaf(first->left);		//recusion is used there for getting leaf
		if(first->left==NULL&&first->right==NULL)	//this is a necessary condition for getting leaf 
		{
		printf(" %d ",first->info);
		b[count]=first->info;			// puts leaf node value into an arrey 
		count++;
		}
		findleaf(first->right);
		
	}
	return b;						// pass an 1st element address  of an arrey to void main ()
}

int countleaf(struct node *first)/*   countleaf funtion used to count no. of leaf node in a  tree  */
{
	static int count=0;	//used static int to maintain value of count 
	if(first!=NULL)					
	{
		countleaf(first->left);		//recusion is used there for getting leaf
		if(first->left==NULL&&first->right==NULL)	//this is a necessary condition for getting leaf 
		{
		
		count++;
		}
		countleaf(first->right);
		
	}
	return count ;					// return the value count to void main ()
}
// A function that terminates when enter key is pressed
void fun()
{
    printf("fun() starts \n");
    printf("Press enter to stop fun \n");
    while(1)
    {
        if (getchar())
            break;
    }
    printf("fun() ends \n");
}

void main ()
{
	int i,a[500],*l,k,p,q,r,d[500],j,count=0;
	time_t y;							//time is variable so we use seed as time
	
	 /* Intializes random number generator */
    srand((unsigned) time(&y));
	for(i=0;i<100;i++)
	{
		
		a[i]=rand()%(100);		//take a random no.s
		printf("%d ",a[i]);			
	}
		
	maketree(a);			//used for making binary search tree
	/*
		main logic behind for given question :
	  	 find leaf node because we know that MAX. distance between any two nodes always present between  a pair of 
	  	leaf node
	*/
	printf("\n\nLEAF NODES ARE :");
	/* there l is pointer which has address first element of above arrey ,given arrey contain all leaf node and by the help
		l pointer we can find any leaf node 
	*/
	l=findleaf(first);				// used to find leaf node and print them 
	
	printf("\n\n");
	
	k=countleaf(first); 			// used for count the no. of leaf node
	
	/* 
		below loop I used depth funtion to find all depth of LEAF nodes and then find LCA of all pair of leaf node and then 
		find p+q-2*r and put this value for all pair into a new arrey that is d[count]
	*/
	for(i=0;i<k;i++)
	{
		for(j=i+1;j<k;j++)
		{
			p=depth(first,*(l+i));
			q=depth(first,*(l+j));
			temp=search(first,*(l+i),*(l+j));
			r=depth(first,temp->info);
			d[count]=(p+q)-2*r;
			
			count++;
		}
	}
	/*
		there i sort the above arrey and print the last value that is max. distance between any two leaf node
	*/
	for(i=0;i<count;i++)
	{
		for(j=i+1;j<count;j++)
		{
			if(d[i]>d[j])
			{
				p=d[i];
				d[i]=d[j];
				d[j]=p;
			}
		}
	}
	printf("\nDIAMETER of TREE is :%d\n",d[count-1]);
	
	 // Calculate the time taken by fun()
    clock_t t;
    t = clock();
    fun();
    t = clock() - t;
    double time_taken = ((double)t)/CLOCKS_PER_SEC; // in seconds
 
    printf("\nfun() took %f seconds to execute \n", time_taken);
}

/* 
	"these all are average time complexity "
	there 'n' is number of total nodes
	
	time complexity of 'make tree' funtion is O(logn)
	time complexity of 'depth','findleaf','countleaf' funtion are O(n)
	time complexity of'search'  funtion is O(logn)
	time complexity of void funtion is ' constant+O(count^2) '
	total complexity is sum of these 
*/
	
