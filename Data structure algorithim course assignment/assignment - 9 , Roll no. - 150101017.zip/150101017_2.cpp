/*
	Name = Bishwendra Choudhary
	Rol no. = 150101017
*/	


#include <iostream>
#include <cmath>
#include <cstdlib>
using namespace std;

/*
	defining the structure
	*/
struct node
{
    int key;
    int degree;
    node* parent;
    node* child;
    node* left;
    node* right;
    char mark;
    char C;
};
/*
	make a class that contain all function used in this 
	code
	*/
class FibonacciHeap
{
    private:
        int nH;
        node *H;
    public:
        node* InitializeFIB_Heap();
        int Fib_link(node*, node*, node*);
        node *Create_node(int);
        node *FIB_Insert(node *, node *);
        node *FIB_Union(node *, node *);
        node *FIB_Extract_Min(node *);
        int FIB_Consolidate(node *);
        int Print_Root_List(node *);
       
       /*
       	it is our constructor
       	*/
        FibonacciHeap()
        {
            H = InitializeFIB_Heap();
        }
};
/*
 * Initialize Heap
 */
node* FibonacciHeap::InitializeFIB_Heap()
{
    node* np;
    np = NULL;
    return np;
}
/*
 * Create Node
 */
node* FibonacciHeap::Create_node(int value)
{
    node* x = new node;
    x->key = value;
    return x;
}
/*
 * Insert Node function is below there are two intially if H is NULL that case you have to make a self loop 
 	after that you concat the node with given H 
 	and finally set pointer on minimum key
 */
node* FibonacciHeap::FIB_Insert(node* H, node* x)
{
    x->degree = 0;
    x->parent = NULL;
    x->child = NULL;
    x->left = x;
    x->right = x;
    x->mark = 'F';
    x->C = 'N';
    if (H != NULL)
    {
        (H->left)->right = x;
        x->right = H;
        x->left = H->left;
        H->left = x;
        if (x->key < H->key)
            H = x;
    }
    else
    {
        H = x;
    }
    nH = nH + 1;
    return H;
}
/*
 * Link Nodes in Fibonnaci Heap used when we do Consolidate
 in this function we just cut y node from root list and make it child of the z node
 */
int FibonacciHeap::Fib_link(node* H1, node* y, node* z)
{
    (y->left)->right = y->right;
    (y->right)->left = y->left;
    if (z->right == z)
        H1 = z;
    y->left = y;
    y->right = y;
    y->parent = z;
    if (z->child == NULL)
        z->child = y;
    y->right = z->child;
    y->left = (z->child)->left;
    ((z->child)->left)->right = y;
    (z->child)->left = y;
    if (y->key < (z->child)->key)
        z->child = y;
    z->degree++;
}
/*
 * Union Nodes in Fibonnaci Heap we union H1 and H2
 */
node* FibonacciHeap::FIB_Union(node* H1, node* H2)
{
    node* np;
    node* H = InitializeFIB_Heap();
    H = H1;
    (H->left)->right = H2;
    (H2->left)->right = H;
    np = H->left;
    H->left = H2->left;
    H2->left = np;
    return H;
}
/*
 Used as printf the given root list 
 */
int FibonacciHeap::Print_Root_List(node* H)
{
    node* p = H;
    if (p == NULL)
    {
        cout<<"The Heap is Empty"<<endl;
        return 0;
    }
    cout<<"The root nodes of Heap are: "<<endl;
    do
    {
        cout<<p->key;
        p = p->right;
        if (p != H)
        {
            cout<<"-->";
        }
    }
    while (p != H && p->right != NULL);
    cout<<endl;
}
/*
 * Extract Min Node in Fibonnaci Heap
 */
node* FibonacciHeap::FIB_Extract_Min(node* H1)
{
    node* p;
    node* ptr;
    node* z = H1;
    p = z;
    ptr = z;
    /*
    	it is our base condition 
    	*/
    if (z == NULL)
        return z;
        
    node* x;
    node* np;
    x = NULL;
    /*
    	if child of extract min is not null then we add all child root list into the main root list
    	*/
    if (z->child != NULL)
        x = z->child;
    if (x != NULL)
    {
        ptr = x;
        do
        {
            np = x->right;
            (H1->left)->right = x;
            x->right = H1;
            x->left = H1->left;
            H1->left = x;
            if (x->key < H1->key)
                H1 = x;
            x->parent = NULL;
            x = np;
        }
        while (np != ptr);
    }
    /*
    	concate the child list to main root list
    	*/
    (z->left)->right = z->right;
    (z->right)->left = z->left;
    H1 = z->right;
    /*
    	after that consolidate
    	*/
    if (z == z->right && z->child == NULL)
        H = NULL;
    else
    {
        H1 = z->right;
        FIB_Consolidate(H1);
    }
    nH = nH - 1;
    return p;
}
/*
 * Consolidate Node in Fibonnaci Heap
 */
int FibonacciHeap::FIB_Consolidate(node* H1)
{
	
    int d, i;
    float f = (log(nH)) / (log(2));
    int D = f;
    node* A[D];
    for (i = 0; i <= D; i++)
        A[i] = NULL;
    node* x = H1;
    node* y;
    node* np;
    node* pt = x;
    do
    {
        pt = pt->right;
        d = x->degree;
        while (A[d] != NULL)
        {
            y = A[d];
            if (x->key > y->key)
            {
                np = x;
                x = y;
                y = np;
            }
            if (y == H1)
                H1 = x;
            Fib_link(H1, y, x);
            if (x->right == x)
                H1 = x;
                A[d] = NULL;
            d = d + 1;
        }
        A[d] = x;
        x = x->right;
    }
    while (x != H1);
    H = NULL;
    for (int j = 0; j <= D; j++)
    {
        if (A[j] != NULL)
        {
            A[j]->left = A[j];
            A[j]->right =A[j];
            if (H != NULL)
            {
                (H->left)->right = A[j];
                A[j]->right = H;
                A[j]->left = H->left;
                H->left = A[j];
                if (A[j]->key < H->key)
                H = A[j];
            }
            else
            {
                H = A[j];
            }
            if(H == NULL)
                H = A[j];
            else if (A[j]->key < H->key)
                H = A[j];
        }
    }
}
 




int main()
{
    int n, m, l;
    FibonacciHeap fh;
    node* p;
    node* H;
    H = fh.InitializeFIB_Heap();
    /*
    	this are all four case that you want given below
    	*/
    while (1)
    {
        cout<<"----------------------------"<<endl;
        cout<<"Operations on Fibonacci heap"<<endl;
        cout<<"----------------------------"<<endl;
        cout<<"1)MAKE FIB -HEAP"<<endl;
        cout<<"2)FIB -HEAP-Insert "<<endl;
        cout<<"3)FIB -HEAP-Extract"<<endl;
        cout<<"4)FIB -HEAP-UNION"<<endl;
        
        cout<<"5)Exit"<<endl;
        cout<<"Enter Your Choice: ";
        cin>>l;
        switch(l)
        {
        	
        case 1 :
		
			 cout<<"The Heap is: "<<endl;
            fh.Print_Root_List(H);
            break;
				
					
        case 2:
            cout<<"Enter the element to be inserted: ";
            cin>>m;
            p = fh.Create_node(m);
            H = fh.FIB_Insert(H, p);
            break;
        case 3:
            p = fh.FIB_Extract_Min(H);
            if (p != NULL)
                cout<<"The node with minimum key: "<<p->key<<endl;
            else
                cout<<"Heap is empty"<<endl;
            break;
      	case 4 :
      			cout<<"Union with given FIB - heap \n";
      			cout<<"No. of nodes you want to add :"<<endl;
      			int q;
				cin>>q;
				for(int i=0;i<q;i++)
					{
						 p = fh.Create_node(rand()%100+rand()%10);
           				 H = fh.FIB_Insert(H, p);
					}
				cout<<q<<" Random nodes are Unioned with the given FIB-HEAP "<<endl;
				break;	
      
        
           
        case 5:
            exit(1);
        default:
            cout<<"Wrong Choice"<<endl;
        }
    }
    return 0;
}
