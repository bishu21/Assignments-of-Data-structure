#include<stdio.h>
#include<stdlib.h>
#include<limits.h>



/*
	this function is used for find the minimum key value which are not in MST 
*/	
int minkey(int v,int key[],int mstset[])
{
	int i;
	int minkey =INT_MAX;
	int minkey_index;
	
	for(i=0;i<v;i++)
	{
		/*
				mstset[i]==0  shows that that minkey is not in MST set
		*/
		if(key[i]<minkey&&mstset[i]==0)
		{
			minkey=key[i];
			minkey_index=i;
		}
	}
	/*
	send the index of that minkey
	*/
	return minkey_index;
}

/*
	it is used for print the MST TREE
	*/
void print_mst(int v,int a[v][v],int parent[])
{
	int i;
	
	for(i=1;i<v;i++)
	{
		printf("EDEGE  %d - %d  weight -%d\n",parent[i],i,a[i][parent[i]]);
	}
	
}
/*
	this the prim function used for connecting the minimum weight egdes
	*/
void prim(int v,int a[][v])
{
	int i,j;
	/*
	parent array for storing parent of node 
	mstset contain those node which are in MST 
	key is just for storing weight
	*/
	int parent[1000];
	int key[1000];
	int mstset[100];
	
	for(i=0;i<v;i++)
	{
		key[i]=INT_MAX;
		mstset[i]=0;
		
	}
	
	key[0]=0;
	parent[0]=-1;
	
 
	
	for(i=0;i<v-1;i++)
	{
		int u = minkey(v,key,mstset);
		
		mstset[u]=1;
	/*
		there I select all nodes which are connected to given MST nodes
		assign key and parent also to all those nodes
		*/	
		
		
		for(j=0;j<v;j++)
		{
			if(a[u][j]&&mstset[j]==0&&a[u][j]<key[j])
			{
				key[j]=a[u][j];
				parent[j]=u;
			}
		}
		
	}
	
	print_mst(v,a,parent);


}
void main ()
{
	int v,e,i,j;
	printf("no. of vertices :");
	scanf("%d",&v);
	printf("no.of edges:");
	scanf("%d",&e);
	getchar();
	int a[v][v];

   for(i=0;i<v;i++)
   {
   		for(j=0;j<v;j++)
   		{
   			scanf("%d",&a[i][j]);
	  	 }
   }
    
   	
	prim(v,a);
	
}


