/*
name bishwendra choudhary
roll no 150101017
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

struct Listnode                         //Adjacency List Node
{
    int data;
    char colour;                        //w= white, g=gray, b=black
    int start;                          //start and finish time in dfs
    int finish;
    struct Listnode *next;              //Pointer to next element in the list
};

struct Listhead                         //Stores first node element of each row in the list
{
    struct Listnode *head;              //head points to first element having an edge with corr. List head
    int colour;
    int start;
    int finish;
    int pie;                            //pie is predecessor
};

struct Graph                            //Structure to define graph of v vertices
{
    int v;
    struct Listhead *array;
};
struct Listnode *createnewnode(int v)                         //Function to create new node in the list
{
    struct Listnode *new_node = (struct Listnode*)malloc(sizeof(struct Listnode));
    new_node->data=v;
    new_node->colour='w';
    new_node->next=NULL;
    return new_node;
} ;

struct Graph *creategraph(int v)                                //Function to create graph of V vertices
{
    struct Graph* graph=(struct Graph*)malloc(sizeof(struct Graph));
    graph->v=v;
    graph->array=(struct Listhead*)malloc((v+1)*sizeof(struct Listhead));
    int i;
    for(i=1;i<=v;i++)
    {
        graph->array[i].head=NULL;
        graph->array[i].colour='w';                     //Initially all nodes are white
        graph->array[i].pie=-1;

    }
    return graph;
};
void add_edge(struct Graph *graph,int first,int second)       //Function to add edge between two given vertex first and second
{
    struct Listnode* newnode=createnewnode(second);
    newnode->next=graph->array[first].head;
    graph->array[first].head=newnode;
}    //Time-O(E)
void printgraph(struct Graph* graph)                         //Function to print graph in form of adjacency list
{
    int i;
    for (i= 1; i <= graph->v; i++)
    {
         struct Listnode* temp = graph->array[i].head;
         printf("%d ->",i);
        while (temp)
        {
            printf(" %d ", temp->data);
            temp = temp->next;
        }
        printf("\n");
    }
} //Time-O(V+E)
void printgraph_scc(struct Graph* graph)                     //Similar Function to print Graph of SCC's
{
    int i;
    for (i= 1; i <= graph->v; i++)
    {
         struct Listnode* temp = graph->array[i].head;
         printf("(SCC_%d) ->",i);
        while (temp)
        {
            printf(" (SCC_%d) ", temp->data);
            temp = temp->next;
        }
        printf("\n");
    }
} //Time-O(V+E)
void DFS(struct Graph *graph,int array[],int *head,int b[])
//Standard DFS Function which calls DFS on vertices acc. to elements of array b[]
//array and head are used to make stack acc. to finishing time
{
    int time=0;
    int i;
    for(i=1;i<=graph->v;i++)
    {
        if(graph->array[(b[i-1])].colour=='w')                //b[0] is the first node on which dfs is called
        {
                DFS_VISIT(graph,b[i-1],time,array,head);
        }
    }
}//Time-O(V+E)
void DFS_VISIT(struct Graph* graph,int i,int time,int array[],int *head)
//Standard DFS_VISIT Function which also creates an array sorted acc to decreasing finishing time
//Head is used to increase size of array
{
    int k;
    time =time+1;

    graph->array[i].start=time;
    graph->array[i].colour='g';
    struct Listnode* temp = graph->array[i].head;
    while(temp)
    {
        if(graph->array[temp->data].colour=='w')
        {
            graph->array[temp->data].pie=i;
            DFS_VISIT(graph,temp->data,time,array,head);
        }
        temp=temp->next;
    }
    graph->array[i].colour='b';
    time =time+1;
    graph->array[i].finish=time;
    array[*head]=i;
    *head= *head + 1;
} //Time-O(V+E)
void SCC(struct Graph *graph,int arr[],int *head,int stack[],int v,int scc[],int *index)
//SCC Function to print all the SCC's
//Index gives me total no. of SCC's in the graph
//scc[u] tells that vertex u is contained in i'th SCC with index name i
//stack is used to call DFS on nodes acc to given nodes in the stack
//arr stores connected components to a particular node and head is for increasing array size
{
    int i;
    int time=0;
    for(i=0;i<v;i++)
    {
       int j=(*head);
       if(graph->array[(stack[i])].colour=='w')
       {
         DFS_VISIT(graph,stack[i],time,arr,head);
         printf("SCC_%d :  ",*index);
         for(;j<(*head);j++)
         {
           scc[(arr[j])]=*index;
           printf(" %d ",arr[j]);
         }
           printf("\n");
           *index = *index + 1;
       }

    }
} //Time-O(V+E)
struct Graph* Transpose(struct Graph *graph,int v)    //Simple Function to create Transpose Graph of given graph G
{
    struct Graph* graphtrans=creategraph(v);
    int i;
    for(i=1;i<=v;i++)
    {
        struct Listnode* temp = graph->array[i].head;
        while(temp)
        {
            add_edge(graphtrans,temp->data,i);
            temp=temp->next;
        }
    }
 return graphtrans;
}; //Time-O(V+E)
int checklist(struct Graph *graph,int a,int b)                 //Function to check whether same edge is not being created again
{
     struct Listnode* temp = graph->array[a].head;
     while(temp)
     {
         if(temp->data==b)
         {
             return 0;
         }
         temp=temp->next;
     }
     return 1;
} //Time-O(E)
void main()
{
    int a,b;
    int n,e;
    int i=0;
    printf("Enter the number of nodes:\n");
    scanf("%d",&n);                                           //n is no. of vertices
    printf("Enter the number of edges :\n");
    scanf("%d",&e);                                           //e is no of edges
    struct Graph* graph=creategraph(n);                       //creating graph
    printf("Enter the value of nodes to be connected\n");
    for(i=0;i<e;i++)
    {
        scanf("%d",&a);
        scanf("%d",&b);
        add_edge(graph,a,b);                                  //adding edges
    }
    printf("Graph G:\n");
    printgraph(graph);
    struct Graph* graphtrans;
    graphtrans=Transpose(graph,n);                            //Creating transpose graph
    printf("Transpose of G:\n");
    printgraph(graphtrans);
    int array[n],normal[n],stack[n],arr[n];
    int head=0,head2=0;
    for(i=1;i<=n;i++)
    {
        normal[i-1]=i;                                    //normal is an array passed to dfs acc. to simple increasing i by 1
    }
    DFS(graph,array,&head,normal);                        //creates an array sorted acc. to finishing time
    int scc[n+1];
    //scc is an array in which scc[u] tells that vertex u is contained in i'th SCC with index name i
    int index=1;
    for(i=0;i<n;i++)
    {
        stack[i]=array[n-i-1];                       //Creating stack from array
    }
    printf("Strongly Connected Components:\n");
    SCC(graphtrans,arr,&head2,stack,n,scc,&index);   //creates scc[],and prints all SCC's and tells no. of SCC's
    struct Graph* sccgraph=creategraph(index-1);     //Creating graph for SCC's
    for (i= 1; i <= graph->v; i++)                   //Exploring edges of given graph G
    {
        struct Listnode* temp = graph->array[i].head;
        while (temp)
        {
          //if there is an edge (u,v) in G the we check if u,v belongs to same SCC or not
          //if not then we add an edge between corr SCC's
            if(scc[i] != scc[temp->data])
            {
             //Checking if same edge not gets repeated
             if(checklist(sccgraph,scc[i],scc[temp->data])==1)
                add_edge(sccgraph,scc[i],scc[temp->data]);
            }
            temp = temp->next;
        }
    }
    //Full Loop takes //Time-O(V+E)
    printf("Component Graph of SCC's:\n");
    printgraph_scc(sccgraph);                          //Printing the component graph
}


