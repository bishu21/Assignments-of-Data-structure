/*
	bishwendra choudhary
	roll no. = 150101017
	*/

#include <stdio.h>
#include <stdlib.h>

int visited[30],grey_time[30],black_time[30],time=0;


struct node_element
{
    int dest;
    struct node_element* next;
};
 

struct adjlist
{
    struct node_element *head;  
};
 

struct grap
{
    int V;
    struct adjlist* array;
};
 

struct node_element* newnode_element(int dest)
{
    struct node_element* newNode =
            (struct node_element*) malloc(sizeof(struct node_element));
    newNode->dest = dest;
    newNode->next = NULL;
    return newNode;
}
 

struct grap* createarray(int V)
{
    struct grap* graph = (struct grap*) malloc(sizeof(struct grap));
    graph->V = V;
 
    graph->array = (struct adjlist*) malloc(V * sizeof(struct adjlist));
 

    int i;
    for (i = 0; i < V; ++i)
        graph->array[i].head = NULL;
 
    return graph;
}
 
/*
used for adding edge in adjency list
*/
void addEdge(struct grap* graph, int src, int dest)
{
  
    struct node_element* newNode = newnode_element(dest);
    newNode->next = graph->array[src].head;
    graph->array[src].head = newNode;
 

 /*   newNode = newnode_element(src);
    newNode->next = graph->array[dest].head;
    graph->array[dest].head = newNode;*/
}
 
/*
used for printing adjaency list as your convince
*/
void printGraph(struct grap* graph)
{
    int v;
    for (v = 0; v < graph->V; ++v)
    {
        struct node_element* pCrawl = graph->array[v].head;
        printf("\n Adjacency list of vertex %d\n head ", v);
        while (pCrawl)
        {
            printf("-> %d", pCrawl->dest);
            pCrawl = pCrawl->next;
        }
        printf("\n");
    }
}





/*
	
	to visit in dfs we use this funtion
*/

int dfs_visit(struct grap *graph,int src)
{
struct node_element *temp=graph->array[src].head;
int i,j,k;



time=time+1;

grey_time[src]=time;

visited[src]=1;

	while(temp!=NULL){
		i=temp->dest;
		if(visited[i]==0){
			
			dfs_visit(graph,i);
			
		}
		temp=temp->next;
	}

visited[src]=2;
time=time+1;
black_time[src]=time;

return 0;
}





int main()
{
int i,j,k,node,edge,src,dest,flag;
// I take no. of vertices there
printf("no of nodes :");
scanf("%d",&node);

struct node_element *temp;
// no. of edges also 
printf("no of edges:");
scanf("%d",&edge);
/*
make a array of size = node*/
struct grap *newgraph=createarray(node);
/*
	it is for connect a graph and make adjaency list
	*/

	for(i=0;i<edge;i++){
		scanf("%d %d",&src,&dest);
		
		printf("src=%d dest=%d\n",src,dest);
		addEdge(newgraph,src,dest);
	}


	for(i=0;i<node+1;i++){
		visited[i]=0;
		black_time[i]=0;
		grey_time[i]=0;
	}	


	for(i=0;i<node;i++){
		
		if(visited[i]==0)		
			dfs_visit(newgraph,i);
	}



printf("\nsrc-dest \t type of edge\n");

for(i=0;i<node;i++){
	for(j=0;j<node;j++){
		printf("%d-%d",i,j);		
			
		temp=newgraph->array[i].head;
		
		while(temp!=NULL){
			if(temp->dest==j)flag=1;
			temp=temp->next;
		}


		if(flag==1){

			if(grey_time[i]<grey_time[j] && grey_time[j]<black_time[j] && black_time[j]<black_time[i])
				printf("\t tree edge or forward edge present\n");
	
			else if(grey_time[j]<=grey_time[i] && grey_time[i]<black_time[i] && black_time[i]<=black_time[j])
				printf("\t back edge present\n");
		
			else if(grey_time[j]<black_time[j] && black_time[j]<grey_time[i] && grey_time[i]<black_time[i])
				printf("\t cross edge is present\n");
		}
		
		else printf("\t no edge present\n");

		flag=0;		
	}

		
}




return 0;
}














