/*
	name- bishwendra choudhary
	Roll no. - 150101017
	*/
 
#include<stdio.h>
#include<stdlib.h>
#include<malloc.h>
 
 /*
 	it is our basic structure that we have required
 	*/
struct node {
    int key;
    int degree;
    struct node* parent;
    struct node* leftchild;
    struct node* sibling;
}*start;
 
 	
struct node* MAKE_BINOMIAL_HEAP();
int LINK(struct node*, struct node*);
struct node* createnode(int);
struct node* BINOMIAL_HEAP_UNION(struct node*, struct node*);
struct node* BINOMIAL_HEAP_INSERT(struct node*, struct node*);
struct node* MERGE(struct node*, struct node*);
struct node* BINOMIAL_HEAP_EXTRACT_MIN(struct node*);
int REVERT_LIST(struct node*);
int DISPLAY(struct node*);


 
int count = 1;
 /*
 	this function is basically used for 
 	define a pointer point to start point of heap
 	*/
struct node* MAKE_BINOMIAL_HEAP() {
    struct node* np;
    np = NULL;
    return np;
}
 
struct node * H = NULL;
struct node *Hr = NULL;
 /*
 	This is used for link to trees  which has no leftchild ,both of 
 	them*/
int LINK(struct node* y, struct node* z) {
    y->parent = z;
    y->sibling = z->leftchild;
    z->leftchild = y;
    z->degree = z->degree + 1;
}
 /*
 	creating a node whose key is given 
 	send to the user
 	*/
struct node* createnode(int k) {
    struct node* p;//new node;
    p = (struct node*) malloc(sizeof(struct node));
    p->key = k;
    return p;
}
 /*
 	This is most important function used Union two heap
 	*/
struct node* BINOMIAL_HEAP_UNION(struct node* H1, struct node* H2) {
    struct node* prev_x;
    struct node* next_x;
    struct node* x;
    struct node* H = MAKE_BINOMIAL_HEAP();
    /*
    	there we call merge function for merging two 
    	binomial heap and return to single binomial heap that is 'H'
    	*/
    H = MERGE(H1, H2);
    if (H == NULL)
        return H;
    prev_x = NULL;
    x = H;
    next_x = x->sibling;
    /*
    	there I write all four case that is refered by sir
    	*/
    while (next_x != NULL) {
        if ((x->degree != next_x->degree) || ((next_x->sibling != NULL)
                && (next_x->sibling)->degree == x->degree)) {
            prev_x = x;
            x = next_x;
        } else {
            if (x->key <= next_x->key) {
                x->sibling = next_x->sibling;
                LINK(next_x, x);
            } else {
                if (prev_x == NULL)
                    H = next_x;
                else
                    prev_x->sibling = next_x;
                LINK(x, next_x);
                x = next_x;
            }
        }
        next_x = x->sibling;
    }
    return H;
}
 /*
 	for insertion we also required a binomial union fuction 
 	In this function we insert a individual elements to given heap
 	*/
struct node* BINOMIAL_HEAP_INSERT(struct node* H, struct node* x) {
    struct node* H1 = MAKE_BINOMIAL_HEAP();
    x->parent = NULL;
    x->leftchild = NULL;
    x->sibling = NULL;
    x->degree = 0;
    H1 = x;
    H = BINOMIAL_HEAP_UNION(H, H1);
    return H;
}
 /*
 	merge to heap in non-decreasing order is done by this function
 	merge is basically done on the basis of degree of root list
 	*/
struct node* MERGE(struct node* H1, struct node* H2) {
    struct node* H = MAKE_BINOMIAL_HEAP();
    struct node* y;
    struct node* z;
    struct node* a;
    struct node* b;
    y = H1;
    z = H2;
    if (y != NULL) {
        if (z != NULL && y->degree <= z->degree)
            H = y;
        else if (z != NULL && y->degree > z->degree)
            /* need some modifications here;the first and the else conditions can be merged together!!!! */
            H = z;
        else
            H = y;
    } else
        H = z;
    while (y != NULL && z != NULL) {
        if (y->degree < z->degree) {
            y = y->sibling;
        } else if (y->degree == z->degree) {
            a = y->sibling;
            y->sibling = z;
            y = a;
        } else {
            b = z->sibling;
            z->sibling = y;
            z = b;
        }
    }
    return H;
}
 /*
 	this is basically used for checking that our root list is correct or not
 	*/
int DISPLAY(struct node* H) {
    struct node* p;
    if (H == NULL) {
        printf("\nHEAP EMPTY");
        return 0;
    }
    printf("\nThe Root List Nodes are given below-: \n");
    p = H;
    /* there i used while loop to print all the root list  node of given binomial heap
	*/ 
    while (p != NULL) {
        printf("%d", p->key);
        if (p->sibling != NULL)
            printf("-->");
        p = p->sibling;
    }
    printf("\n");
}
 /*
 	extract min function for removing min. element from heap 
 	and do again union
 	*/
struct node* BINOMIAL_HEAP_EXTRACT_MIN(struct node* H1) {
    int min;
    struct node* t = NULL;
    struct node* x = H1;
    struct node *Hr;
    struct node* p;
    Hr = NULL;
    if (x == NULL) {
        printf("\nNOTHING TO EXTRACT");
        return x;
    }
    
    p = x;
    while (p->sibling != NULL) {
        if ((p->sibling)->key < min) {
            min = (p->sibling)->key;
            t = p;
            x = p->sibling;
        }
        p = p->sibling;
    }
    if (t == NULL && x->sibling == NULL)
        H1 = NULL;
    else if (t == NULL)
        H1 = x->sibling;
    else if (t->sibling == NULL)
        t = NULL;
    else
        t->sibling = x->sibling;
    if (x->leftchild != NULL) {
        revert(x->leftchild);
        (x->leftchild)->sibling = NULL;
    }
    H = BINOMIAL_HEAP_UNION(H1, Hr);
    return x;
}
 /*
 Its used for adjust the leftchild
 */
int revert(struct node* y) {
    if (y->sibling != NULL) {
        revert(y->sibling);
        (y->sibling)->sibling = y;
    } else {
        Hr = y;
    }
}
/*
	this is our main function from which we call all above function
	*/


void showHeap( struct node *H, int depth )
{
int i;
if ( H->sibling!= NULL ) 
{
showHeap( H->sibling, depth );

printf("\n");

for(i=0;i<depth;i++)
printf("      ");

}

printf("    ");


printf("%d",H->key);


if ( H->leftchild!= NULL ) 
showHeap( H->leftchild, depth + 1 );
}
 
int main() {
    int j, n, m,a[100];
    FILE *fp;
    /*
    you have file of name"te.txt" from which you are taking input
    */
    fp = fopen("te.txt","r");
    
    char l,c,u,i,d,f;
    struct node* p;
    struct node* np;
    char ch;
    printf("\nENTER THE NUMBER OF ELEMENTS:");
    scanf("%d", &n);
   	/*
   	There I apply switch case with taking input as 'char' and call case by 'char'
   	*/
    do {
        printf("\nYou have to Enter 'c' for taking input from file \n");
        printf("\nc)MAKE BINOMIAL HEAP\nu)BINOMIAL HEAP UNION\ni)INSERT AN ELEMENT\nd)EXTRACT THE MINIMUM KEY NODE\nf)QUIT\n");
        
		scanf("%c", &l);
        switch (l) {
        case 'i':
            do {
                printf("\nENTER THE ELEMENT TO BE INSERTED:");
                scanf("%d", &m);
                p = createnode(m);
                H = BINOMIAL_HEAP_INSERT(H, p);
                printf("\nNOW THE HEAP IS:\n");
                DISPLAY(H);
                printf("\nINSERT MORE(y/Y)= \n");
                fflush(stdin);
                scanf("%c", &ch);
            } while (ch == 'Y' || ch == 'y');
            break;
        case 'd':
            do {
                printf("\nEXTRACTING THE MINIMUM KEY NODE");
                p = BINOMIAL_HEAP_EXTRACT_MIN(H);
                if (p != NULL)
                    printf("\nTHE EXTRACTED NODE IS %d", p->key);
                printf("\nNOW THE HEAP IS:\n");
                DISPLAY(H);
                printf("\nEXTRACT MORE(y/Y)\n");
                fflush(stdin);
                scanf("%c", &ch);
            } while (ch == 'Y' || ch == 'y');
            break;
        case 'c':
            do {
                 printf("\nENTER THE ELEMENTS:\n");
                 
    for (j = 1; j <= n; j++) {
        fscanf(fp,"%d",&m);
       
        np = createnode(m);
        H = BINOMIAL_HEAP_INSERT(H, np);
    }
    DISPLAY(H);
            } while (ch == 'Y' || ch == 'y');
            
            break;
        case 'u':
        	printf("Union with H so put an element key : ");
        	struct node *nod=(struct node*)malloc(sizeof(struct node));
        	nod->degree=0;
        	nod->leftchild=NULL;
        	nod->parent=NULL;
        	nod->sibling=NULL;
        	scanf("%d",&nod->key);
         H=  BINOMIAL_HEAP_INSERT( H,  nod);
         DISPLAY(H);
            break;
        case 'f':
        	fclose(fp);
            printf ("Stucture of binomial heap (rotated 90 degrees ccwise):\n");
if ( H== NULL )  printf( "Empty heap");
else showHeap( H, 0 );
            return;
       
    } 
    
}while (l != 5);
	
	
	


}
