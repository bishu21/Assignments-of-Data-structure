/*
	Name - Bishwendra choudhary
	Roll no. - 150101017
*/	
#include <iostream>
#include<stdlib.h>
#include <string.h>

using namespace std;

struct Book
{
    char title[20];
    char author[20];
    int year_of_publication;
    int copies_sold;
    float cost;
    long long int ISBN;
    struct Book *left;
    struct Book *right;
};
/*
	Its for assign values to new created node
	*/
struct Book *createnode(int a,int b,float c,long long int d,char e[],char f[])
{
	
	struct Book *temp =(struct Book *)malloc(sizeof(struct Book));
	
	strcpy(temp->author,f);
	
	strcpy(temp->title,e);
	temp->year_of_publication=a;
	temp->copies_sold=b;
	temp->cost=c;
	temp->ISBN=d;
	temp->right=NULL;
	temp->left=NULL;
	
	return temp;
}
/*
	BST_recur for calling itself upto not get node whose child are NULL
	and put given into that place
	*/
void BST_recur(struct Book *temp,struct Book *current)
{
	/*
	It is for searching in right child of node
	*/
		if(temp->ISBN>current->ISBN)
			{
				if( current->right==NULL)	
					current->right=temp;
				else
					BST_recur(temp,current->right);
			}
	/*
	It is for searching in left child of node
	*/		
		else
			{
				if(current->left==NULL)
			     current->left=temp;
				else
				BST_recur(temp,current->left);
			}
}
/*
	This Bst used to create BST 
	*/
struct Book *BST()
{
	int n;
	struct 	Book *start;
	struct Book  *current;
	cout<<"No. of Books you want to add in BST:";
	cin>>n;
		
	for(int i=0;i<n;i++)
	{
		int a,b,c;
		long long int d;
		char e[20],f[20];
		cout<<"\nTitle of book :";
		cin>>e;
		cout<<"Author of Book :";
		cin>>f;
		cout<<"Year of publication :";
		cin>>a;
	    cout<<"No. of copy sold :";
		cin>>b;
		cout<<"Cost of Book:";
		cin>>c;
		cout<<"ISBN of Book:";
		cin>>d;
		
		struct Book *temp =createnode(a,b,c,d,e,f);
	 	
	 	/*
	 	Intialise the BST
	 	*/
		if(i==0)
		{
		start= temp;
		current=temp;
		}
		/*
		ADD nodes in given BST
		*/
		else
		{
			start =current;
			BST_recur(temp,start);
		}
		
	}
	/*
	return root of BST
	*/
	return current;
}
/*
This function help to increase cost of each BOOK by 10%
*/
void increase_cost(struct Book *p)
{
	if(p!=NULL)
	{
		p->cost=(p->cost)/10+p->cost;
		increase_cost(p->left);
		increase_cost(p->right);
	}
}
/*
	Search book in given BST 
	*/
void search_Book(int a,struct Book *p)
{
	if(a==p->ISBN)
	{
		cout<<" Book is found "<<endl;
		cout<<"No. of copies sold for this Book is   "<<p->copies_sold<<endl;
	}
	if(a>p->ISBN)
	{
		if(p->right==NULL)
		{
			cout<<" NOT Found  ";
		}	
		else
		search_Book(a,p->right);	
	}
	if(a<p->ISBN)
	{
		if(p->left==NULL)
		{
			cout<<" NOT Found  ";
			}	
		else
		search_Book(a,p->left);
	}
}
void insert(struct Book *p)
{
        int a,b,c;
		long long int d;
		char e[20],f[20];
		cout<<"Title of book :";
		cin>>e;
		cout<<"Author of Book :";
		cin>>f;
		cout<<"Year of publication : ";
		cin>>a;
	    cout<<"No. of copy sold : ";
		cin>>b;
		cout<<"Cost of Book:";
		cin>>c;
		cout<<"ISBN of Book:";
		cin>>d;
		struct Book *temp =createnode(a,b,c,d,e,f);
		/*
		CALl BST_recur for getting correct location 
		*/
		BST_recur(temp,p);
}	
int main ()
{
	int k;
	struct Book *p=BST();
    cout<<"\nInsert a given book\n ";
    insert(p);
    cout<<"\nCost of each book is increase by 10% \n";
    increase_cost(p);
    cout<<"\nput ISBN Value of Book that you want to search : ";
    cin>>k;
    search_Book(k,p);
	return 0;
}
