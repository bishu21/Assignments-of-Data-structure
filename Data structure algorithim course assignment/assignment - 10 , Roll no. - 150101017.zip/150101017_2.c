/*
	Name - Bishwendra Choudhary
	Roll no. - 150101017
	*/

#include<stdio.h>
#include<stdlib.h>

/*
	define a structure according to question 
	*/
struct node 
{
	int degree;
	int coeff;
	struct node *ptr;	
};
/*
	function of create node 
	take input as degree and coeff
	*/
struct node *createnode(int a,int b)
{
	struct node *temp =(struct node *)malloc(sizeof(struct node));
	temp->degree=a;
	temp->ptr=NULL;
	temp->coeff=b;
	return temp;
}
/*
	This is function used to make sparse Polynomial by linklist 
	Give coeff value as Zero and value according to yours
	*/
struct node *polynomial(int a)
{
	int i;
	struct node *temp,*start,*current;
	
	for(i=0;i<=a;i++)
	{
		if(i==0)
		{
			int j ;
			printf("coefficient of degree %d :",a-i);
			scanf("%d",&j);
			start =createnode(a-i,j);
			current=start;
		}
		else
		{
			int j ;
			printf("coefficient of degree %d :",a-i);
			scanf("%d",&j);
			temp = createnode(a-i,j);
			start->ptr=temp;
			start=temp;	
		}
	}
	return current;
}
/*
	This is hash function 
	Put value in arrey according to their degree
	
	*/
void hash(struct node *P1,struct node *P2,int A[])
{
	int i ,j;
	struct node *current=P2;
	while(P1)
	{
		P2=current;
		while(P2)
		{
			A[P1->degree+P2->degree]+=P1->coeff*P2->coeff;
			P2=P2->ptr;
		}
		P1=P1->ptr;
	}
	
}
void main()
{
	int i,a,b;
	printf("Max degree of Polynomial 1 :");
	scanf("%d",&a);
	struct node *P1=polynomial(a);


	printf("\n\nMax degree of Polynomial 2 :");
	scanf("%d",&b);
	struct node *P2=polynomial(b);

	printf("\n\n\n");
	/*
	Make a arrey of size equal to sum of degree poly 1 + degree poly. 2
	*/
	int A[a+b];
	
	/*
	assign all value intial Zero so that no random value in Arrey
	*/
	for(i=0;i<=a+b;i++)
	A[i]=0;
	
	hash(P1,P2,A);
	/*
	This loop helps to print the polynomial which is  multiplication of two sparse polynomial
	*/
	for(i=0;i<a+b;i++)
	{
		if(A[i]!=0)
		printf("%d X^%d + ",A[i],i);
	}
	printf("%d X^%d ",A[i],i);
}
