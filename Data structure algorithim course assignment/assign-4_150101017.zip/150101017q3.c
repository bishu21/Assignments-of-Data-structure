#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/*

      roll no. = 150101017
      name bishwendra choudhary


*/


typedef enum{head,entry}tagfield;  // for storing whether node is head or element(not used)

typedef struct{                    // for storing row no., col. no. , and value

    int row;
    int col;
    int val;

}entrynode;

typedef struct{                     // a complete node

        struct matrixnode *down;    // for pointing to the element down
        struct matrixnode *right;   // for pointing to the element right

        tagfield tag;               // for storing whether it is head or entry

        union{                      // entry for matrix element
                                    // next for head(although next is not used)

                struct matrixnode *next;
                entrynode entry;

        };




}matrixnode;

// matrix node *top stores no. of rows , columns, no. of non zero elements
// and points to header row and column

// to create header row whose down pointer points to matrix elements
void header_row_creator(matrixnode *top);

// to create header column whose right pointer points to matrix elements
void header_column_creator(matrixnode *top);

// to create matrix entry elements
void matrix_node_creator(matrixnode *top,int r,int c,int v);  // row,col,value given as input


int main()
{
        srand(time(NULL));

        // assigning variables
        int r,c;                    // no. of rows and columns
        int n;                      // no. of non zero elements
        int i,j;                    // index integers
        int x;                      // max. no. of elements elements
        int temp;                   // temporary
        int row,col;                // row, col values of matrix entry node
        int b;                      // for assigning random value
        int maxi;                   // maximum




        // input is taken from user
        scanf("%d",&r);
        scanf("%d",&c);
        x = r*c;

        scanf("%d",&n);

        while(n>x){

            printf("%d * %d matrix can't contain %d elements.Enter value of no. of non zero elements again.\n",r,c,n);
            scanf("%d",&n);

        }





        // choosing n unique addresses in matrix
        int a[n];

        a[0] = rand() % x;

        // values assigned ranges from 0 t0 x-1
        for(i=1;i<n;i++){

            a[i] =  rand() % x ;

            re:
            //for making sure each value is unique
            for(j=0;j<i;j++){

                if(a[i] == a[j]){          // if value has already occurred, it is reassigned

                    a[i] =  rand() % x ;
                    goto re;

                }


            }


        }

        /* now unique address is extracted from a[i] as follows

            row no. = a[i]/c
            col. no. = a[i] % c

        */


        // top node is created
        matrixnode *top;
        // k and l are used for various purposes
        matrixnode *k;
        matrixnode *l;

        top = (matrixnode*)malloc(sizeof(matrixnode));
        top->tag = head;
        top->entry.row = r;
        top->entry.col = c;
        top->entry.val = n;
        top->right = NULL;
        top->down = NULL;

        // header row is created
        for(i=0;i<c;i++)
            header_row_creator(top);

        // header column is created
        for(i=0;i<r;i++)
            header_column_creator(top);


        // Now matrix is generated and printed
        printf("Generated Matrix\n");
        printf("Row   Column   Value");

        for(i=0;i<n;i++){

                //unique address is extracted
                row = a[i]/c;
                col = a[i] % c;


                //random value is generated
                b = 1 + rand() % 500 ;


                //matrix entry node is created
                matrix_node_creator(top,row,col,b);
                printf("\n%d       %d        %d",row,col,b);

        }
        k=top;
        maxi = -1;







        // maximum is calculated
        for(i=0;i<r;i++){

            //elements are compared row wise
            k = k->down;
            l = k;

                //comparison in a row takes place till l reaches header again
                while(l->right != k){

                    l = l->right;

                    //comparing values
                    if(l->entry.val > maxi){

                        maxi = l->entry.val;

                    }


                }

                // now we move to next row


        }

        //highest no. is printed
        printf("\n\nHighest number : %d",maxi);




    return 0;
}

// function to create header row
void header_row_creator(matrixnode *top){

    // new node is made
    // since this is header row, right will point to next header
    // whereas down will point to matrix entry
    // since initially there is no matrix entry, initially down points to node itself

    matrixnode *new_head;
    new_head = (matrixnode*)malloc(sizeof(matrixnode));
    new_head->tag = head;
    new_head->down = new_head;


    matrixnode *q;
    q = top->right;



    // if there is no element to the right of top, new head is inserted here
    if(top->right == NULL){

          top->right = new_head;
          new_head->right = new_head;

    }else{

        // else the last header node is found out as it points to starting header node
        while(q->right != top->right){

            q = q->right;

        }
        //new head is inserted here
        q->right = new_head;
        new_head->right = top->right;

    }

}



// function to create header column
void header_column_creator(matrixnode *top){

    // new node is made
    // since this is header column, down will point to next header
    // whereas right will point to matrix entry
    // since initially there is no matrix entry, initially right points to node itself


    matrixnode *new_head;
    new_head = (matrixnode*)malloc(sizeof(matrixnode));
    new_head->tag = head;
    new_head->right = new_head;


    matrixnode *q;
    q = top->down;



    // if there is no element to the right of top, new head is inserted here
    if(top->down == NULL){

          top->down = new_head;
          new_head->down = new_head;

    }else{

        // else the last header node is found out as it points to starting header node
        while(q->down != top->down){

            q = q->down;

        }
        //new head is inserted here
        q->down = new_head;
        new_head->down = top->down;

    }

}


// Function to create and insert a matrix entry node
void matrix_node_creator(matrixnode *top,int r,int c,int v){

    //new node is created
    // space is allocated and all values are assigned
    matrixnode *new_node;
    new_node = (matrixnode*)malloc(sizeof(matrixnode));
    new_node->tag = entry;
    new_node->entry.row = r;
    new_node->entry.col = c;
    new_node->entry.val = v;
    new_node->right = NULL;
    new_node->down = NULL;

    // this is the header element whose right pointer points to the row where new node has to be inserted
    matrixnode *ro;

    // this is the header element whose down pointer points to the column where new node has to be inserted
    matrixnode *co;

    matrixnode *p;
    matrixnode *q;

    int i,j;

    // we reach correct row where new node is to be inserted
    ro = top->down;
    i=0;
    while(i<r){

        ro = ro->down;
        i++;

    }

    q = ro->right;

    // if there is no element in the row, new node is inserted here
    if(ro->right == NULL){

        ro->right = new_node;
        new_node->right = ro;


    }else{

        //else if col. no. where it is to be inserted is lesser than col. no. of first matrix node
        if(q->entry.col > c){

            // new node becomes first matrix entry node in its row
            new_node->right = ro->right;
            ro->right = new_node;


           //else if col. no. where it is to be inserted is greater than col. no. of first matrix node
        }else if(q->entry.col < c){

                // a situation is reached where previous like previous situation occurs
                // by cont. going to next row entry
                while(q->entry.col < c ){

                    p = q->right;

                    // to check whether new node will become the last entry or not
                    if(p == ro){

                        break;

                    }else{

                        q = q->right;

                    }



                }

                // new node is inserted at appropriate location
                new_node->right = q->right;
                q->right = new_node;


        }




    }

    // we reach correct column where new node is to be inserted
    co = top->right;

    j=0;

    while(j<c){

        co = co->right;
        j++;

    }

    q = co->down;

     // if there is no element in the column, new node is inserted here
    if(co->down == NULL){

        co->down = new_node;
        new_node->down = co;


    }else{

        //else if row no. where it is to be inserted is lesser than row no. of first matrix node


        if(q->entry.row > r){

            // new node becomes first matrix entry node in its column
            new_node->down = co->down;
            co->down = new_node;


        //else if row no. where it is to be inserted is greater than row no. of first matrix node
        }else if(q->entry.row < r){

                // a situation is reached where previous like previous situation occurs
                // by cont. going to next column entry

                while(q->entry.row < r ){

                    p = q->down;

                    // to check whether new node will become the last entry or not
                    if(p == co){

                        break;

                    }else{

                        q = q->down;

                    }

                 // new node is inserted at appropriate location
                new_node->down = q->down;
                q->down = new_node;


            }

        }

    }

}

