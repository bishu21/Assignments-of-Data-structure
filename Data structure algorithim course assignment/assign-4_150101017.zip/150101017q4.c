/*
	name - bishwendra choudhary
	roll no. - 150101017
*/


#include<stdlib.h>
#include<stdio.h>

typedef struct
{
    int input;
    int check;
}path;

//int count=0;

int checkboundry(int n,int m,path a[][m])                           //check no of terminals
{int i,j,c=0;

 for(i=0;i<n;i++)
    if(a[i][0].input==1 && a[i][0].check==0)
    {c++;
     a[i][0].check=1;
     }

 for(i=0;i<n;i++)
    if(a[i][m-1].input==1 && a[i][m-1].check==0)
    {c++;
     a[i][m-1].check=1;
     }

 for(i=0;i<m;i++)
    if(a[0][i].input==1 && a[0][i].check==0)
     {c++;
     a[0][i].check=1;
     }

 for(i=0;i<n;i++)
    if(a[n-1][i].input==1 && a[n-1][i].check==0)
     {c++;
      a[n-1][i].check=1;
     }

 return c;
}



int checkpath(int n,int m,path a[][m],int row,int col)
{int i,j,k;


  if(row==n-1 || col==m-1 || row==0 || col==0)                  //check for end
    if(a[row][col].check==0)
     {printf("submitted");
     return 0;
       }

  a[row][col].check=1;



  if(row+1<n && a[row+1][col].input==1 && a[row+1][col].check==0)           //check down
       if(checkpath(n,m,a,row+1,col)==0)
         return 0;


  if(row>0 && a[row-1][col].input==1 && a[row-1][col].check==0)           //check up
        if(checkpath(n,m,a,row-1,col)==0)
         return 0;


  if(col+1<m && a[row][col+1].input==1 && a[row][col+1].check==0)           //check  right
        if(checkpath(n,m,a,row,col+1)==0)
            return 0;


  if(col>0 && a[row][col-1].input==1 && a[row][col-1].check==0)           //check left
        if(checkpath(n,m,a,row,col-1)==0)
            return 0;


 //count++;
return 1;

}




int find(int n,int m,path a[][m])
{int i,j;

  for(i=0;i<n;i++)
    if(a[i][0].input==1 && a[i][0].check==0)
       {a[i][0].check=1;
        if(checkpath(n,m,a,i,0)==0)
            return 0;
       }

  for(i=0;i<n;i++)
    if(a[i][m-1].input==1 && a[i][m-1].check==0)
       {a[i][m-1].check=1;
         if(checkpath(n,m,a,i,m-1)==0)
            return 0;
       }


  for(i=0;i<m;i++)
    if(a[0][i].input==1 && a[0][i].check==0)
        {a[0][i].check=1;
         if(checkpath(n,m,a,0,i)==0)
            return 0;
        }

  for(i=0;i<m;i++)
    if(a[n-1][i].input==1 && a[n-1][i].check==0)
        {a[n-1][i].check=1;
         if(checkpath(n,m,a,n-1,i)==0)
            return 0;
        }

 printf("bad luck\n");

}




void main()
{
    int n,x,m;
    printf("n*m\n");
    scanf("%d%d",&n,&m);
    char c;
    path a[n][m];

    int i,j;

    for(j=0;j<n;j++)
     for(i=0;i<m;i++)
      {scanf(" %c",&c);
       if(c=='l' || c=='L')         //taking input  land is assinged as 1
        a[j][i].input=1;
         else
            a[j][i].input=0;
       a[j][i].check=0;
      }


 /*for(j=0;j<n;j++)                       //outputing the input
  {for(i=0;i<m;i++)
    printf("%d",a[j][i].input);
    printf("\n");
  }
*/

x=checkboundry(n,m,a);
// printf("%d\n",x);


  for(j=0;j<n;j++)
     for(i=0;i<m;i++)
        a[j][i].check=0;

  if(x==2)                                 // check for path only if two inputs
   find(n,m,a);
    else
        printf("sorry not exactly two terminal\n");


 //printf("\n%d\n",count);

}
